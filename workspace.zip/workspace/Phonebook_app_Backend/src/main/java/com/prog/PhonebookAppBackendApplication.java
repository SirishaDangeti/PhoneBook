package com.prog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhonebookAppBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhonebookAppBackendApplication.class, args);
	}

}
