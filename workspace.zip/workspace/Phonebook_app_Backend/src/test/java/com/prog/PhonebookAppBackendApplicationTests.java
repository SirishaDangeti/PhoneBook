package com.prog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhonebookAppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
